#include "types.h"
#include "stat.h"
#include "user.h"
#include "fcntl.h"

int main(int argc, char *argv[]) {
    int fd_output;
    int i, j;
    int sum = 0;
    int current_num = 0;
    int in_number = 0;
    char output_str[16];
    
    
    if(argc < 2) {
        printf(2, "Usage: fmd_sum <input_string>\n");
        exit();
    }
    
   
    for(j = 1; j < argc; j++) {
        char *input_string = argv[j];
        current_num = 0;
        in_number = 0;
        
        
        for(i = 0; input_string[i] != '\0'; i++) {
            if(input_string[i] >= '0' && input_string[i] <= '9') {
                // If digit, add to current number
                current_num = current_num * 10 + (input_string[i] - '0');
                in_number = 1;
            } else {
                // If non-digit and we were reading a number, add to sum
                if(in_number) {
                    sum += current_num;
                    current_num = 0;
                    in_number = 0;
                }
            }
        }
        
        // If argument ended with a number, add it too
        if(in_number) {
            sum += current_num;
        }
    }
    
    fd_output = open("result.txt", O_CREATE | O_WRONLY);
    if(fd_output < 0) {
        printf(2, "fmd_sum: cannot create result.txt\n");
        exit();
    }
    
    // Convert sum to string
    int temp = sum;
    int digits = 0;
    
    if(temp == 0) {
        output_str[0] = '0';
        digits = 1;
    } else {
        while(temp > 0) {
            digits++;
            temp /= 10;
        }
    }
    
    // Write number to buffer
    temp = sum;
    for(i = digits - 1; i >= 0; i--) {
        output_str[i] = (temp % 10) + '0';
        temp /= 10;
    }
    output_str[digits] = '\n';
    
    if(write(fd_output, output_str, digits + 1) != digits + 1) {
        printf(2, "fmd_sum: write error\n");
        close(fd_output);
        exit();
    }
    
    close(fd_output);
    exit();
}