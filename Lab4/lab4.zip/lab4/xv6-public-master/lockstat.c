#include "types.h"
#include "stat.h"
#include "user.h"
#include "param.h"

int
main(void)
{
  uint64 score[NCPU];
  int i;

  printf(1, "Initial lock stats:\n");
  if(getlockstat(score) < 0){
    printf(1, "getlockstat failed\n");
    exit();
  }
  for(i = 0; i < NCPU; i++)
    printf(1, "CPU %d score: %d\n", i, (int)score[i]);

  int nchild = 4;
  for(i = 0; i < nchild; i++){
      int k;
      for(k = 0; k < 100; k++){
        int pid = fork();
        if(pid == 0){
            exit();
      }
        else if(pid>0) {
            wait();
        }
    }
  }

  for(i = 0; i < nchild; i++)
    wait();

  printf(1, "Final lock stats:\n");
  if(getlockstat(score) < 0){
    printf(1, "getlockstat failed\n");
    exit();
  }
  for(i = 0; i < NCPU; i++)
    printf(1, "CPU %d score: %d\n", i, (int)score[i]);

  exit();
}