#include "types.h"
#include "user.h"

int main(void) {
    int pid;

    printf(1, "Starting Sleeplock Ownership Test...\n");

    test_acquire();
    printf(1, "Parent (PID %d) acquired the lock.\n", getpid());

    pid = fork();
    
    if (pid < 0) {
        printf(1, "Fork failed\n");
        exit();
    }

    if (pid == 0) {
        printf(1, "Child (PID %d) running. Trying to release parent's lock...\n", getpid());
        
        test_release(); 
        
        printf(1, "ERROR: Child managed to release the lock! Test FAILED.\n");
        exit();
    } else {
        wait(); 
        
        printf(1, "Parent releasing the lock correctly.\n");
        test_release();
        printf(1, "Test finished.\n");
    }
    
    exit();
}