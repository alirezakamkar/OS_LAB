// rwlock.h

struct rwlock {
    struct spinlock lk; 
    int readers;        
    int writing;        
    char *name;         
  };