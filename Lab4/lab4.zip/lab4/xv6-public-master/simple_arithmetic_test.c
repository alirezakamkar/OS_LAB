#include "types.h"
#include "user.h"
#include "stat.h"

int call_simple_arithmetic(int a, int b) {
  int result;
  asm volatile(
    "movl %1, %%edi\n\t"
    "movl %2, %%esi\n\t"
    "movl $22, %%eax\n\t"
    "int $64\n\t"
    "movl %%eax, %0"
    : "=r" (result)
    : "r" (a), "r" (b)
    : "%eax", "%edi", "%esi"
  );
  return result;
}

int main(int argc, char *argv[]) {
  if (argc != 3) {
    printf(2, "Usage: %s <a> <b>\n", argv[0]);
    exit();
  }

  int a = atoi(argv[1]);
  int b = atoi(argv[2]);
  printf(1, "(%d + %d) * (%d - %d) = ", a, b, a, b);
  int result = call_simple_arithmetic(a, b);
  exit();
}