#include "types.h"
#include "user.h"

#define NCPU 8

int main(void) {
    uint64 scores[NCPU];
    int i, pid;
    
    printf(1, "Starting Lock Contention Test...\n\n");

    if(getlockstat(scores) < 0){
        printf(1, "Error getting initial stats\n");
        exit();
    }
    
    printf(1, "=== Initial Stats (Before Workload) ===\n");
    for(i=0; i<NCPU; i++){
        printf(1, "CPU %d: %d\n", i, (int)scores[i]);
    }


    printf(1, ">>> Creating 4 processes to fight for the lock...\n");
    
    for(i=0; i<4; i++){
        pid = fork();
        if(pid == 0){
            int j;
            for(j=0; j<1000; j++){
                contentious_lock();
            }
            exit();
        }
    }

    for(i=0; i<4; i++){
        wait();
    }
    printf(1, ">>> Workload finished.\n\n");


    getlockstat(scores);
    
    printf(1, "=== Final Stats (After Workload) ===\n");
    for(i=0; i<NCPU; i++){
        printf(1, "CPU %d: %d\n", i, (int)scores[i]);
    }
    
    exit();
}