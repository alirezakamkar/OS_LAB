// Console input and output.
// Input is from the keyboard or serial port.
// Output is written to the screen and serial port.

#include "types.h"
#include "defs.h"
#include "param.h"
#include "traps.h"
#include "spinlock.h"
#include "sleeplock.h"
#include "fs.h"
#include "file.h"
#include "memlayout.h"
#include "mmu.h"
#include "proc.h"
#include "x86.h"


int numBack = 0;
int numBackSaved = 0;
int is_copy = 0;
int copy_is_end = 0;

static void consputc(int);

static int panicked = 0;

static struct {
  struct spinlock lock;
  int locking;
} cons;

static void
printint(int xx, int base, int sign)
{
  static char digits[] = "0123456789abcdef";
  char buf[16];
  int i;
  uint x;

  if(sign && (sign = xx < 0))
    x = -xx;
  else
    x = xx;

  i = 0;
  do{
    buf[i++] = digits[x % base];
  }while((x /= base) != 0);

  if(sign)
    buf[i++] = '-';

  while(--i >= 0)
    consputc(buf[i]);
}
//PAGEBREAK: 50

// Print to the console. only understands %d, %x, %p, %s.
void
cprintf(char *fmt, ...)
{
  int i, c, locking;
  uint *argp;
  char *s;

  locking = cons.locking;
  if(locking)
    acquire(&cons.lock);

  if (fmt == 0)
    panic("null fmt");

  argp = (uint*)(void*)(&fmt + 1);
  for(i = 0; (c = fmt[i] & 0xff) != 0; i++){
    if(c != '%'){
      consputc(c);
      continue;
    }
    c = fmt[++i] & 0xff;
    if(c == 0)
      break;
    switch(c){
    case 'd':
      printint(*argp++, 10, 1);
      break;
    case 'x':
    case 'p':
      printint(*argp++, 16, 0);
      break;
    case 's':
      if((s = (char*)*argp++) == 0)
        s = "(null)";
      for(; *s; s++)
        consputc(*s);
      break;
    case '%':
      consputc('%');
      break;
    default:
      // Print unknown % sequence to draw attention.
      consputc('%');
      consputc(c);
      break;
    }
  }

  if(locking)
    release(&cons.lock);
}

void
panic(char *s)
{
  int i;
  uint pcs[10];

  cli();
  cons.locking = 0;
  // use lapiccpunum so that we can call panic from mycpu()
  cprintf("lapicid %d: panic: ", lapicid());
  cprintf(s);
  cprintf("\n");
  getcallerpcs(&s, pcs);
  for(i=0; i<10; i++)
    cprintf(" %p", pcs[i]);
  panicked = 1; // freeze other CPU
  for(;;)
    ;
}

//PAGEBREAK: 50
#define BACKSPACE 0x100
#define CRTPORT 0x3d4
#define KEY_TAB 9
static ushort *crt = (ushort*)P2V(0xb8000);  // CGA memory

static void
cgaputc(int c)
{
  int pos;

  // Cursor position: col + 80*row.
  outb(CRTPORT, 14);
  pos = inb(CRTPORT+1) << 8;
  outb(CRTPORT, 15);
  pos |= inb(CRTPORT+1);

  if(c == '\n')
    pos += 80 - pos%80;
  else if(c == BACKSPACE){
    for (int i = pos - 1; i < pos + numBack; i++)
         crt[i] = crt[i+1];

    if(pos > 0) --pos;
  }
  else {
    for (int i =  pos + numBack; i > pos; i--)
      crt[i] = crt[i-1];
    crt[pos++] = (c&0xff) | 0x0700;  // black on white
  }

  if(pos < 0 || pos > 25*80)
    panic("pos under/overflow");

  if((pos/80) >= 24){  // Scroll up.
    memmove(crt, crt+80, sizeof(crt[0])*23*80);
    pos -= 80;
    memset(crt+pos, 0, sizeof(crt[0])*(24*80 - pos));
  }

  outb(CRTPORT, 14);
  outb(CRTPORT+1, pos>>8);
  outb(CRTPORT, 15);
  outb(CRTPORT+1, pos);
  crt[pos] = ' ' | 0x0700;
}

void
consputc(int c)
{
  if(panicked){
    cli();
    for(;;)
      ;
  }

  if(c == BACKSPACE){
    uartputc('\b'); uartputc(' '); uartputc('\b');
  } else
    uartputc(c);
  cgaputc(c);
}

#define INPUT_BUF 128
struct {
  char buf[INPUT_BUF];
  uint r;  // Read index
  uint w;  // Write index
  uint e;  // Edit index
} input;

#define C(x)  ((x)-'@')  // Control-x

static void backCursor(){
  int pos;
  // get cursor position
  outb(CRTPORT, 14);
  pos = inb(CRTPORT+1) << 8;
  outb(CRTPORT, 15);
  pos |= inb(CRTPORT+1);

  // move back
  if(crt[pos - 2] != ('$' | 0x0700))
      pos--;
  // reset cursor
  outb(CRTPORT, 14);
  outb(CRTPORT+1, pos>>8);
  outb(CRTPORT, 15);
  outb(CRTPORT+1, pos);
}

static void forwardCursor(){
  int pos;
  // get cursor position
  outb(CRTPORT, 14);
  pos = inb(CRTPORT+1) << 8;
  outb(CRTPORT, 15);
  pos |= inb(CRTPORT+1);

  // move forward
  pos++;
  // reset cursor
  outb(CRTPORT, 14);
  outb(CRTPORT+1, pos>>8);
  outb(CRTPORT, 15);
  outb(CRTPORT+1, pos);
}

static void shiftRight(char *buf)
{
  for (int i = input.e; i > input.e - numBack; i--)
  {
    buf[(i) % INPUT_BUF] = buf[(i - 1) % INPUT_BUF];
  }
}

static void shiftLeft(char *buf)
{
  for (int i = input.e - numBack - 1; i < input.e; i++)
  {
    buf[(i) % INPUT_BUF] = buf[(i + 1) % INPUT_BUF];
  }
  input.buf[input.e] = ' ';
}

#define LEFT_ARROW          0xE4
#define RIGHT_ARROW         0xE5
#define CTRL_A              0x01
#define CTRL_D              0x04
#define CTRL_Z              0x1A

static int find_next_word_start() {
    int current_pos = input.e - numBack;
    char *buf = input.buf;

    if(current_pos >= input.e) return 0;

    while(current_pos < input.e && buf[current_pos % INPUT_BUF] == ' ') {
        current_pos++;
    }
    while(current_pos < input.e && buf[current_pos % INPUT_BUF] != ' ') {
        current_pos++;
    }
    while(current_pos < input.e && buf[current_pos % INPUT_BUF] == ' ') {
        current_pos++;
    }

    return current_pos - (input.e - numBack);
}

static int find_prev_word_start() {
    int current_pos = input.e - numBack - 1;
    char *buf = input.buf;

    if(current_pos < (int)input.w) return 0;

    while(current_pos >= (int)input.w && buf[current_pos % INPUT_BUF] == ' ') {
        current_pos--;
    }
    while(current_pos >= (int)input.w && buf[current_pos % INPUT_BUF] != ' ') {
        current_pos--;
    }

    return (input.e - numBack) - (current_pos + 1);
}

static void delete_last_char() {
    if(input.e > input.w) {
        input.e--;
        consputc(BACKSPACE);

        if(numBack > 0) {
            numBack--;
        }
    }
}

static char *commands[] = {
  "ls", "ln", "wc", "cat", "echo", "grep", "kill", "mkdir", "rm",
  "sh", "ps", "forktest", "init", "date", "touch" , "find_sum"
};
static int ncommands = sizeof(commands) / sizeof(commands[0]);

static int get_word_start() {
    int abs_end = (int)input.e;
    int abs_cursor = abs_end - numBack; // absolute index where cursor is (before char at abs_cursor)
    int abs_start = abs_cursor;
    // move left until start or space or input.w
    while(abs_start > (int)input.w && input.buf[(abs_start-1) % INPUT_BUF] != ' ')
        abs_start--;
    return abs_start;
}

// helper to copy prefix into local buffer; returns length
static int copy_prefix(char *dst) {
    int abs_start = get_word_start();
    int abs_cursor = (int)input.e - numBack;
    int len = abs_cursor - abs_start;
    if(len <= 0) {
        dst[0] = '\0';
        return 0;
    }
    for(int i = 0; i < len; i++) {
        dst[i] = input.buf[(abs_start + i) % INPUT_BUF];
    }
    dst[len] = '\0';
    return len;
}

// helper: insert a character ch at cursor position (i.e. at abs_cursor) and update input.e
static void insert_char_at_cursor(char ch) {
    int abs_cursor = (int)input.e - numBack;
    // shift buffer content right by 1 from abs_cursor..input.e-1
    for(int i = (int)input.e; i > abs_cursor; i--) {
        input.buf[i % INPUT_BUF] = input.buf[(i-1) % INPUT_BUF];
    }
    input.buf[abs_cursor % INPUT_BUF] = ch;
    input.e++;
    // visually output char at cursor; cgaputc uses numBack to shift visible chars right
    consputc((int)ch);
}

// helper: reprint current input line (used after printing matches)
static void repaint_input_line() {
    // print the current buffer from input.w to input.e
    for(int i = (int)input.w; i < (int)input.e; i++) {
        consputc(input.buf[i % INPUT_BUF]);
    }
}

// track consecutive tab presses for same prefix
static char last_prefix[INPUT_BUF];
static int last_prefix_len = 0;
static int tab_state = 0; // 0 = none, 1 = one Tab with current prefix, >=2 -> show

void
consoleintr(int (*getc)(void))
{
  int c, doprocdump = 0;

  acquire(&cons.lock);
  while((c = getc()) >= 0){
    switch(c){
    case C('P'):  // Process listing.
      // procdump() locks cons.lock indirectly; invoke later
      doprocdump = 1;
      break;
    case C('U'):  // Kill line.
      while(input.e != input.w &&
            input.buf[(input.e-1) % INPUT_BUF] != '\n'){
        input.e--;
        consputc(BACKSPACE);
      }
      numBack = 0; // reset cursor position
      // reset tab state
      tab_state = 0;
      last_prefix_len = 0;
      last_prefix[0] = '\0';
      break;
    case C('H'): case '\x7f':  // Backspace
      if(input.e != input.w){
        input.e--;
        consputc(BACKSPACE);
        if(numBack > 0) {
            numBack--;
        }
      }
      // any edit resets tab state
      tab_state = 0;
      last_prefix_len = 0;
      last_prefix[0] = '\0';
      break;
    case LEFT_ARROW:
      if((input.e - numBack) > input.w){
        backCursor();
        numBack++;
      }
      if((input.e - numBackSaved) > input.w && is_copy == 1){
        numBackSaved++;
      }
      // movement resets tab state
      tab_state = 0;
      last_prefix_len = 0;
      last_prefix[0] = '\0';
      break;
    case RIGHT_ARROW:
      if(numBack > 0){
        forwardCursor();
        numBack--;
      }
      if(numBackSaved > 0 && is_copy == 1){
        numBackSaved--;
      }
      // movement resets tab state
      tab_state = 0;
      last_prefix_len = 0;
      last_prefix[0] = '\0';
      break;
    case CTRL_D:  // Move to beginning of next word
      if(numBack > 0) {
        int move = find_next_word_start();
        if(move > 0 && move <= numBack) {
          for(int i = 0; i < move; i++) {
            forwardCursor();
            numBack--;
          }
        }
      }
      // reset tab
      tab_state = 0;
      last_prefix_len = 0;
      last_prefix[0] = '\0';
      break;
    case CTRL_A:  // Move to beginning of current/previous word
      if(input.e - numBack > input.w) {
        int move;

        if(numBack == 0 || input.buf[(input.e - numBack) % INPUT_BUF] == ' ') {
          move = find_prev_word_start();
        } else {
          move = 0;
          int temp_pos = numBack;
          while(temp_pos > 0 && input.buf[(input.e - temp_pos) % INPUT_BUF] != ' ') {
            move++;
            temp_pos--;
          }
        }

        if(move > 0) {
          for(int i = 0; i < move; i++) {
            backCursor();
            numBack++;
          }
        }
      }
      // reset tab
      tab_state = 0;
      last_prefix_len = 0;
      last_prefix[0] = '\0';
      break;
    case CTRL_Z:  // Delete last character (by time)
      delete_last_char();
      // reset tab
      tab_state = 0;
      last_prefix_len = 0;
      last_prefix[0] = '\0';
      break;
    case KEY_TAB: {
      // Autocomplete handling
      char prefix[INPUT_BUF];
      int prefix_len = copy_prefix(prefix); // returns 0 if empty
      int matches = 0;
      int match_idx = -1;

      // find matches in commands[]
      for(int i = 0; i < ncommands; i++) {
        if(prefix_len == 0) {
          // empty prefix matches all
          matches++;
          match_idx = i; // last match index; if matches==1 later will be used
        } else {
          // compare prefix
          int ok = 1;
          for(int j = 0; j < prefix_len; j++) {
            if(commands[i][j] == '\0' || commands[i][j] != prefix[j]) {
              ok = 0;
              break;
            }
          }
          if(ok) {
            matches++;
            match_idx = i;
          }
        }
      }

      // check if same prefix as before (to detect consecutive Tab)
      int same_prefix = 0;
      if(prefix_len == last_prefix_len && prefix_len > 0 && last_prefix_len > 0) {
        if(memcmp(prefix, last_prefix, prefix_len) == 0) same_prefix = 1;
      } else if(prefix_len == 0 && last_prefix_len == 0) {
        same_prefix = 1;
      } else {
        same_prefix = 0;
      }

      if(!same_prefix) {
        // new prefix, set tab_state = 1 (first Tab)
        tab_state = 1;
        last_prefix_len = prefix_len;
        memmove(last_prefix, prefix, prefix_len);
        last_prefix[prefix_len] = '\0';
      } else {
        // same prefix as previous Tab => increase tab_state
        tab_state++;
      }

      if(matches == 1) {
        // single match -> complete
        char *m = commands[match_idx];
        int mlen = strlen(m);
        // remaining chars to insert = mlen - prefix_len
        for(int k = prefix_len; k < mlen; k++) {
          insert_char_at_cursor(m[k]);
        }
        // after inserting, reset tab tracking
        tab_state = 0;
        last_prefix_len = 0;
        last_prefix[0] = '\0';
      } else if(matches > 1) {
        if(tab_state >= 2) {
          // print all matches for this prefix
          cprintf("\n");
          for(int i = 0; i < ncommands; i++) {
            int ok = 0;
            if(prefix_len == 0) ok = 1;
            else {
              int r = 1;
              for(int j = 0; j < prefix_len; j++) {
                if(commands[i][j] == '\0' || commands[i][j] != prefix[j]) {
                  r = 0; break;
                }
              }
              if(r) ok = 1;
            }
            if(ok) {
              cprintf("%s  ", commands[i]);
            }
          }
          cprintf("\n");
          // reprint current input line
          repaint_input_line();
          // reset tab tracking
          tab_state = 0;
          last_prefix_len = 0;
          last_prefix[0] = '\0';
        } else {
        }
      } else {
        // matches == 0: nothing to do; reset tab tracking
        tab_state = 0;
        last_prefix_len = 0;
        last_prefix[0] = '\0';
      }
    } break;
    default:
      if(c != 0 && input.e-input.r < INPUT_BUF){
        c = (c == '\r') ? '\n' : c;
        input.buf[input.e++ % INPUT_BUF] = c;
        consputc(c);
        // any text input should reset tab_state
        tab_state = 0;
        last_prefix_len = 0;
        last_prefix[0] = '\0';

        if(c == '\n' || c == C('D') || input.e == input.r+INPUT_BUF){
          input.w = input.e;
          wakeup(&input.r);
          numBack = 0; // reset cursor after enter
        }
      }
      break;
    }
  }
  release(&cons.lock);
  if(doprocdump) {
    procdump();  
  }
}

int
consoleread(struct inode *ip, char *dst, int n)
{
  uint target;
  int c;

  iunlock(ip);
  target = n;
  acquire(&cons.lock);
  while(n > 0){
    while(input.r == input.w){
      if(myproc()->killed){
        release(&cons.lock);
        ilock(ip);
        return -1;
      }
      sleep(&input.r, &cons.lock);
    }
    c = input.buf[input.r++ % INPUT_BUF];
    if(c == C('D')){  // EOF
      if(n < target){
        input.r--;
      }
      break;
    }
    *dst++ = c;
    --n;
    if(c == '\n')
      break;
  }
  release(&cons.lock);
  ilock(ip);

  return target - n;
}

int
consolewrite(struct inode *ip, char *buf, int n)
{
  int i;

  iunlock(ip);
  acquire(&cons.lock);
  for(i = 0; i < n; i++)
    consputc(buf[i] & 0xff);
  release(&cons.lock);
  ilock(ip);

  return n;
}

void
consoleinit(void)
{
  initlock(&cons.lock, "console");

  devsw[CONSOLE].write = consolewrite;
  devsw[CONSOLE].read = consoleread;
  cons.locking = 1;

  ioapicenable(IRQ_KBD, 0);
}
