// plock.h

struct plock_node {
    struct proc *proc;      
    int priority;           
    struct plock_node *next; 
  };
  
  struct plock {
    struct spinlock lk;      
    int locked;              
    struct plock_node *head; 
    char *name;
  };