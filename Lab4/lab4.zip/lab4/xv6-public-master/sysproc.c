#include "types.h"
#include "x86.h"
#include "defs.h"
#include "date.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "proc.h"
#include "spinlock.h"
#include "sleeplock.h"
#include "rwlock.h"
#include "plock.h"

struct sleeplock testlk;
int testlk_init = 0;
struct rwlock test_rw;
int test_rw_initialized = 0;
struct spinlock profile_lock;
int profile_init = 0;
extern struct spinlock tickslock;
extern uint ticks;
extern struct {
  struct spinlock lock;
  struct proc proc[NPROC];
} ptable;


int
sys_fork(void)
{
  return fork();
}

int
sys_exit(void)
{
  exit();
  return 0;  // not reached
}

int
sys_wait(void)
{
  return wait();
}

int
sys_kill(void)
{
  int pid;

  if(argint(0, &pid) < 0)
    return -1;
  return kill(pid);
}

int
sys_getpid(void)
{
  return myproc()->pid;
}

int
sys_sbrk(void)
{
  int addr;
  int n;

  if(argint(0, &n) < 0)
    return -1;
  addr = myproc()->sz;
  if(growproc(n) < 0)
    return -1;
  return addr;
}

int
sys_sleep(void)
{
  int n;
  uint ticks0;

  if(argint(0, &n) < 0)
    return -1;
  acquire(&tickslock);
  ticks0 = ticks;
  while(ticks - ticks0 < n){
    if(myproc()->killed){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
  }
  release(&tickslock);
  return 0;
}

// return how many clock tick interrupts have occurred
// since start.
int
sys_uptime(void)
{
  uint xticks;

  acquire(&tickslock);
  xticks = ticks;
  release(&tickslock);
  return xticks;
}

int
sys_simple_arithmetic(void)
{
  int a, b;
  
  struct proc *curproc = myproc();
  
 a = curproc->tf->edi;  
 b = curproc->tf->esi;
  
  int result = (a + b) * (a - b);
  cprintf("%d\n",result);
  cprintf("simple_arithmetic: a=%d, b=%d, result=%d\n", a, b, result);
  
  return result;
}

int
sys_test_acquire(void)
{
  if(testlk_init == 0){
    initsleeplock(&testlk, "testlock");
    testlk_init = 1;
  }
  
  acquiresleep(&testlk);
  cprintf("Kernel: Lock acquired by PID %d\n", myproc()->pid);
  return 0;
}

int
sys_test_release(void)
{
  cprintf("Kernel: PID %d trying to release lock...\n", myproc()->pid);
  releasesleep(&testlk);
  return 0;
}

void ensure_rw_init() {
  if (!test_rw_initialized) {
    rwlock_init(&test_rw, "test_rwlock");
    test_rw_initialized = 1;
  }
}

int sys_rw_reader_enter(void) {
  ensure_rw_init();
  rwlock_acquire_read(&test_rw);
  return 0;
}

int sys_rw_reader_exit(void) {
  rwlock_release_read(&test_rw);
  return 0;
}
 
int sys_rw_writer_enter(void) {
  ensure_rw_init();
  rwlock_acquire_write(&test_rw);
  return 0;
}

int sys_rw_writer_exit(void) {
  rwlock_release_write(&test_rw);
  return 0;
}

int sys_getlockstat(void) {
  uint64 *score_ptr; 
  
  if(argptr(0, (void*)&score_ptr, sizeof(uint64)*NCPU) < 0)
    return -1;
  
  if(!profile_init){
      initlock(&profile_lock, "profile_lock");
      profile_init = 1;
  }

  uint64 kscores[NCPU]; 

  for(int i = 0; i < NCPU; i++) {
      kscores[i] = profile_lock.total_spins[i]; 
  }
  
  if(copyout(myproc()->pgdir, (uint)score_ptr, (void*)kscores, sizeof(kscores)) < 0)
      return -1;
      
  return 0;
}


int
sys_contentious_lock(void)
{
  if(!profile_init){
      initlock(&profile_lock, "profile_lock");
      profile_init = 1;
  }
  
  acquire(&profile_lock);
  
  volatile int i; 
  for(i = 0; i < 50000; i++) {
  }
  
  release(&profile_lock);
  return 0;
}

struct plock global_plock;
int plock_inited = 0;

void ensure_plock_init() {
    if(!plock_inited){
         plock_init(&global_plock, "global_plock");
         plock_inited = 1;
    }
}

int sys_plock_acquire(void) {
  int priority;
  if(argint(0, &priority) < 0)
    return -1;
  
  ensure_plock_init();
  
  
  plock_acquire(&global_plock, priority);
  return 0;
}

int sys_plock_release(void) {
  ensure_plock_init();
  plock_release(&global_plock);
  return 0;
}