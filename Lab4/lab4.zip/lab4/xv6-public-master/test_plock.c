#include "types.h"
#include "user.h"

void worker(int prio) {
    printf(1, "Child (PID %d) with Priority %d requesting lock...\n", getpid(), prio);
    
    plock_acquire(prio);
    
    printf(1, "Child (PID %d, Prio %d) ACQUIRED lock!\n", getpid(), prio);
    sleep(10); 
    
    plock_release();
    exit();
}

int main(void) {
    printf(1, "Starting Priority Lock Test...\n");

    plock_acquire(100);
    printf(1, "Parent acquired lock. Creating children...\n");

    if(fork() == 0) worker(10); 
    sleep(10); 
    
    if(fork() == 0) worker(50); 
    sleep(10);
    
    if(fork() == 0) worker(30); 
    sleep(10);

    printf(1, "Parent releasing lock. Watch the order!\n");
    plock_release();

    for(int i=0; i<3; i++) wait();

    printf(1, "Test Finished.\n");
    exit();
}