#include "types.h"
#include "user.h"

int main(int argc, char* argv[]) {
    int idproc = getpid(); 
    printf(1, "Process ID is: %d\n", idproc); 
    exit();
}
