#include "types.h"
#include "defs.h"
#include "param.h"
#include "x86.h"
#include "memlayout.h"
#include "mmu.h"
#include "proc.h"
#include "spinlock.h"
#include "plock.h"

void
plock_init(struct plock *pl, char *name)
{
  initlock(&pl->lk, "plock_lk");
  pl->name = name;
  pl->locked = 0;
  pl->head = 0;
}

void
plock_acquire(struct plock *pl, int priority)
{
  acquire(&pl->lk);
  
  if(!pl->locked) {
    pl->locked = 1;
    release(&pl->lk);
    return;
  }

  struct plock_node *node = (struct plock_node*)kalloc();
  if(node == 0)
    panic("plock: out of memory");
    
  node->proc = myproc();
  node->priority = priority;
  
  node->next = pl->head;
  pl->head = node;
  
  sleep(node, &pl->lk);
  
  
  kfree((char*)node); 
  release(&pl->lk);
}

void
plock_release(struct plock *pl)
{
  acquire(&pl->lk);
  
  if(pl->head == 0) {
    pl->locked = 0;
    release(&pl->lk);
    return;
  }

  struct plock_node **ptr = &pl->head;
  struct plock_node **max_prev = 0;
  struct plock_node *max_node = 0;
  int max_prio = -1;

  while(*ptr) {
    struct plock_node *curr = *ptr;
    if(curr->priority > max_prio) {
      max_prio = curr->priority;
      max_node = curr;
      max_prev = ptr;
    }
    ptr = &curr->next;
  }

  if(max_node) {
    *max_prev = max_node->next;
   
    wakeup(max_node); 
  }
  
  release(&pl->lk);
}