#include "types.h"
#include "user.h"

void reader(int id) {
    printf(1, "[Reader %d] Requesting lock...\n", id);
    rw_reader_enter();
    
    printf(1, "[Reader %d] ENTERED. Reading shared data.\n", id);
    sleep(100); 
    printf(1, "[Reader %d] Exiting.\n", id);
    
    rw_reader_exit();
}

void writer(int id) {
    printf(1, "[Writer %d] Requesting lock...\n", id);
    rw_writer_enter();
    
    printf(1, "[Writer %d] ENTERED. Modifying data (EXCLUSIVE).\n", id);
    sleep(100); 
    printf(1, "[Writer %d] Exiting.\n", id);
    
    rw_writer_exit();
}

int main(void) {
    printf(1, "Starting Reader-Writer Lock Test...\n\n");

  
    int i;
    
    if(fork() == 0) {
        writer(1);
        exit();
    }
    
    sleep(10); 

    for(i = 1; i <= 3; i++){
        if(fork() == 0){
            reader(i);
            exit();
        }
    }

    if(fork() == 0) {
        sleep(20); 
        writer(2);
        exit();
    }

    for(i = 0; i < 5; i++) {
        wait();
    }
    
    printf(1, "\nTest Finished.\n");
    exit();
}