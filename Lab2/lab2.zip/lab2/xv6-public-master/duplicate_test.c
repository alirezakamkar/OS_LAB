#include "types.h"
#include "user.h"
#include "stat.h"

int main(int argc, char *argv[]) {
  if (argc != 2) {
    printf(2, "Usage: %s <filename>\n", argv[0]);
    exit();
  }
  
  int result = make_duplicate(argv[1]);
  
  if (result == 0) {
    printf(1, "File duplicated successfully: %s.copy created\n", argv[1]);
  } else if (result == -1) {
    printf(2, "Error: Source file '%s' not found\n", argv[1]);
  } else {
    printf(2, "Error: Duplication failed\n");
  }
  
  exit();
}