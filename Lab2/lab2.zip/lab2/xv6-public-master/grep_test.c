#include "types.h"
#include "user.h"
#include "stat.h"

int main(int argc, char *argv[]) {
  char buffer[512];
  int result;
  
  if (argc != 3) {
    printf(2, "Usage: %s <filename> <keyword>\n", argv[0]);
    exit();
  }
  
  result = grep_search(argv[2], argv[1], buffer, sizeof(buffer));
  
  if (result > 0) {
    printf(1, "Found line (%d bytes): %s\n", result, buffer);
  } else {
    printf(2, "Error: Keyword '%s' not found in file '%s'\n", argv[2], argv[1]);
  }
  
  exit();
}