#include "types.h"
#include "user.h"
#include "stat.h"

int main(int argc, char *argv[]) {
  if (argc != 2) {
    printf(2, "Usage: %s <pid>\n", argv[0]);
    exit();
  }
  
  int pid = atoi(argv[1]);
  int result = show_process_family(pid);
  
  if (result == -1) {
    printf(2, "Error: Process with PID %d not found\n", pid);
  }
  
  exit();
}