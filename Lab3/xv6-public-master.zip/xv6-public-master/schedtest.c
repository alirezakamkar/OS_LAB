// schedtest.c
#include "types.h"
#include "stat.h"
#include "user.h"

void
heavy(int k)
{
  volatile int i, j;
  for(i = 0; i < k; i++){
    for(j = 0; j < 100000; j++){
      // busy work
    }
  }
}

void
run_case(int nprocs, int work)
{
  int i, pid;

  printf(1, "\n=== CASE: nprocs=%d, work=%d ===\n", nprocs, work);

  tputstart(); 
  for(i = 0; i < nprocs; i++){
    pid = fork();
    if(pid < 0){
      printf(1, "fork failed\n");
      exit();
    }
    if(pid == 0){
      heavy(work);
      exit();
    }
  }

  for(i = 0; i < nprocs; i++)
    wait();

  tputend();   
  procinfo();    
}

int
main(int argc, char *argv[])
{
  // چند سناریوی مختلف
  run_case(4, 30);   
  run_case(8, 30);   
  run_case(4, 80);   
  run_case(12, 80);  

  exit();
}

