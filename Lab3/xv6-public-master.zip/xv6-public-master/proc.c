#include "types.h"
#include "defs.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "x86.h"
#include "proc.h"
#include "spinlock.h"

extern uint ticks;
extern struct spinlock tickslock;
extern struct cpu cpus[NCPU];
extern int ncpu;

struct {
  struct spinlock lock;
  struct proc proc[NPROC];
} ptable;

static struct proc *initproc;

int nextpid = 1;
extern void forkret(void);
extern void trapret(void);

uint last_balance_tick[NCPU];
int last_rr_index[NCPU];

static int tput_active = 0;
static uint tput_start_ticks = 0;
static int tput_finished_count = 0;

static void wakeup1(void *chan);

void
pinit(void)
{
  initlock(&ptable.lock, "ptable");
}

int
cpuid()
{
  return mycpu()-cpus;
}

struct cpu*
mycpu(void)
{
  int apicid, i;
  
  if(readeflags()&FL_IF)
    panic("mycpu called with interrupts enabled\n");
  
  apicid = lapicid();
  for (i = 0; i < ncpu; ++i) {
    if (cpus[i].apicid == apicid)
      return &cpus[i];
  }
  panic("unknown apicid\n");
}

struct proc*
myproc(void)
{
  struct cpu *c;
  struct proc *p;
  pushcli();
  c = mycpu();
  p = c->proc;
  popcli();
  return p;
}

static inline int
is_ecore(int id)
{
  return (id % 2) == 0;
}

static inline int
is_pcore(int id)
{
  return (id % 2) == 1;
}

static int
count_procs_on_cpu(int cpu_id)
{
  int cnt = 0;
  struct proc *p;

  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
    if(p->state == UNUSED || p->state == ZOMBIE || p->state == EMBRYO)
      continue;
    if(p->assigned_cpu == cpu_id)
      cnt++;
  }

  return cnt;
}

static struct proc*
pick_proc_ecore(int cpu_id)
{
  int start = last_rr_index[cpu_id];
  int idx = (start + 1) % NPROC;
  int scanned = 0;
  struct proc *p;

  while(scanned < NPROC){
    p = &ptable.proc[idx];

    if(p->state == RUNNABLE && p->assigned_cpu == cpu_id){
      last_rr_index[cpu_id] = idx;
      p->qnticks = 0;
      return p;
    }

    idx = (idx + 1) % NPROC;
    scanned++;
  }

  return 0;
}

static struct proc*
pick_proc_pcore(int cpu_id)
{
  struct proc *p, *best = 0;

  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
    if(p->state != RUNNABLE)
      continue;
    if(p->assigned_cpu != cpu_id)
      continue;

    if(best == 0 || p->create_tick < best->create_tick)
      best = p;
  }

  if(best)
    best->qnticks = 0;

  return best;
}

void
balance_load(int e_cpu)
{
  int c;
  int min_p_cpu = -1;
  int min_p_load = 1000000;

  int e_load = count_procs_on_cpu(e_cpu);

  for(c = 0; c < ncpu; c++){
    if(!is_pcore(c))
      continue;

    int load = count_procs_on_cpu(c);
    if(load < min_p_load){
      min_p_load = load;
      min_p_cpu = c;
    }
  }

  if(min_p_cpu < 0)
    return;

  if(e_load < min_p_load + 3)
    return;

  struct proc *p, *candidate = 0;
  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
    if(p->state == UNUSED || p->state == ZOMBIE)
      continue;
    if(p->assigned_cpu != e_cpu)
      continue;

    if(p->pid == 1)
      continue;

    if(strncmp(p->name, "sh", 2) == 0)
      continue;

    candidate = p;
    break;
  }

  if(candidate){
    candidate->assigned_cpu = min_p_cpu;
    candidate->queue_type = CORE_P;
  }
}

static struct proc*
allocproc(void)
{
  struct proc *p;
  char *sp;

  acquire(&ptable.lock);

  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++)
    if(p->state == UNUSED)
      goto found;

  release(&ptable.lock);
  return 0;

found:
  p->state = EMBRYO;
  p->pid = nextpid++;

  p->create_tick = ticks;
  p->qnticks = 0;

  int best_cpu = 0;
  int best_load = 1000000;
  int c;

  for(c = 0; c < ncpu; c++){
    if(!is_ecore(c))
      continue;

    int load = count_procs_on_cpu(c);
    if(load < best_load){
      best_load = load;
      best_cpu = c;
    }
  }

  p->assigned_cpu = best_cpu;
  p->queue_type = CORE_E;

  release(&ptable.lock);

  if((p->kstack = kalloc()) == 0){
    p->state = UNUSED;
    return 0;
  }
  sp = p->kstack + KSTACKSIZE;

  sp -= sizeof *p->tf;
  p->tf = (struct trapframe*)sp;

  sp -= 4;
  *(uint*)sp = (uint)trapret;

  sp -= sizeof *p->context;
  p->context = (struct context*)sp;
  memset(p->context, 0, sizeof *p->context);
  p->context->eip = (uint)forkret;

  return p;
}

void
userinit(void)
{
  struct proc *p;
  extern char _binary_initcode_start[], _binary_initcode_size[];

  p = allocproc();
  
  initproc = p;
  if((p->pgdir = setupkvm()) == 0)
    panic("userinit: out of memory?");
  inituvm(p->pgdir, _binary_initcode_start, (int)_binary_initcode_size);
  p->sz = PGSIZE;
  memset(p->tf, 0, sizeof(*p->tf));
  p->tf->cs = (SEG_UCODE << 3) | DPL_USER;
  p->tf->ds = (SEG_UDATA << 3) | DPL_USER;
  p->tf->es = p->tf->ds;
  p->tf->ss = p->tf->ds;
  p->tf->eflags = FL_IF;
  p->tf->esp = PGSIZE;
  p->tf->eip = 0;

  safestrcpy(p->name, "initcode", sizeof(p->name));
  p->cwd = namei("/");

  acquire(&ptable.lock);

  p->state = RUNNABLE;

  release(&ptable.lock);
}

int
growproc(int n)
{
  uint sz;
  struct proc *curproc = myproc();

  sz = curproc->sz;
  if(n > 0){
    if((sz = allocuvm(curproc->pgdir, sz, sz + n)) == 0)
      return -1;
  } else if(n < 0){
    if((sz = deallocuvm(curproc->pgdir, sz, sz + n)) == 0)
      return -1;
  }
  curproc->sz = sz;
  switchuvm(curproc);
  return 0;
}

int
fork(void)
{
  int i, pid;
  struct proc *np;
  struct proc *curproc = myproc();

  if((np = allocproc()) == 0){
    return -1;
  }

  if((np->pgdir = copyuvm(curproc->pgdir, curproc->sz)) == 0){
    kfree(np->kstack);
    np->kstack = 0;
    np->state = UNUSED;
    return -1;
  }
  np->sz = curproc->sz;
  np->parent = curproc;
  *np->tf = *curproc->tf;

  np->tf->eax = 0;

  for(i = 0; i < NOFILE; i++)
    if(curproc->ofile[i])
      np->ofile[i] = filedup(curproc->ofile[i]);
  np->cwd = idup(curproc->cwd);

  safestrcpy(np->name, curproc->name, sizeof(curproc->name));

  pid = np->pid;

  acquire(&ptable.lock);

  np->state = RUNNABLE;

  release(&ptable.lock);

  return pid;
}

void
exit(void)
{
  struct proc *curproc = myproc();
  struct proc *p;
  int fd;

  if(curproc == initproc)
    panic("init exiting");

  for(fd = 0; fd < NOFILE; fd++){
    if(curproc->ofile[fd]){
      fileclose(curproc->ofile[fd]);
      curproc->ofile[fd] = 0;
    }
  }

  begin_op();
  iput(curproc->cwd);
  end_op();
  curproc->cwd = 0;

  if(tput_active){
    acquire(&tickslock);
    tput_finished_count++;
    release(&tickslock);
  }

  acquire(&ptable.lock);

  wakeup1(curproc->parent);

  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
    if(p->parent == curproc){
      p->parent = initproc;
      if(p->state == ZOMBIE)
        wakeup1(initproc);
    }
  }

  curproc->state = ZOMBIE;
  sched();
  panic("zombie exit");
}

int
wait(void)
{
  struct proc *p;
  int havekids, pid;
  struct proc *curproc = myproc();
  
  acquire(&ptable.lock);
  for(;;){
    havekids = 0;
    for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
      if(p->parent != curproc)
        continue;
      havekids = 1;
      if(p->state == ZOMBIE){
        pid = p->pid;
        kfree(p->kstack);
        p->kstack = 0;
        freevm(p->pgdir);
        p->pid = 0;
        p->parent = 0;
        p->name[0] = 0;
        p->killed = 0;
        p->state = UNUSED;
        release(&ptable.lock);
        return pid;
      }
    }

    if(!havekids || curproc->killed){
      release(&ptable.lock);
      return -1;
    }

    sleep(curproc, &ptable.lock);
  }
}

void
scheduler(void)
{
  struct cpu *c = mycpu();
  int id = cpuid();
  struct proc *p;

  c->proc = 0;
  
  for(;;){
    sti();

    acquire(&ptable.lock);

    if(is_ecore(id))
      p = pick_proc_ecore(id);
    else
      p = pick_proc_pcore(id);

    if(p){
      c->proc = p;
      switchuvm(p);
      p->state = RUNNING;
      swtch(&(c->scheduler), p->context);
      switchkvm();
      c->proc = 0;
    }

    release(&ptable.lock);
  }
}

void
sched(void)
{
  int intena;
  struct proc *p = myproc();

  if(!holding(&ptable.lock))
    panic("sched ptable.lock");
  if(mycpu()->ncli != 1)
    panic("sched locks");
  if(p->state == RUNNING)
    panic("sched running");
  if(readeflags()&FL_IF)
    panic("sched interruptible");
  intena = mycpu()->intena;
  swtch(&p->context, mycpu()->scheduler);
  mycpu()->intena = intena;
}

void
yield(void)
{
  acquire(&ptable.lock);
  myproc()->state = RUNNABLE;
  sched();
  release(&ptable.lock);
}

void
forkret(void)
{
  static int first = 1;
  release(&ptable.lock);

  if (first) {
    first = 0;
    iinit(ROOTDEV);
    initlog(ROOTDEV);
  }
}

void
sleep(void *chan, struct spinlock *lk)
{
  struct proc *p = myproc();
  
  if(p == 0)
    panic("sleep");

  if(lk == 0)
    panic("sleep without lk");

  if(lk != &ptable.lock){
    acquire(&ptable.lock);
    release(lk);
  }
  p->chan = chan;
  p->state = SLEEPING;

  sched();

  p->chan = 0;

  if(lk != &ptable.lock){
    release(&ptable.lock);
    acquire(lk);
  }
}

static void
wakeup1(void *chan)
{
  struct proc *p;

  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++)
    if(p->state == SLEEPING && p->chan == chan)
      p->state = RUNNABLE;
}

void
wakeup(void *chan)
{
  acquire(&ptable.lock);
  wakeup1(chan);
  release(&ptable.lock);
}

int
kill(int pid)
{
  struct proc *p;

  acquire(&ptable.lock);
  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
    if(p->pid == pid){
      p->killed = 1;
      if(p->state == SLEEPING)
        p->state = RUNNABLE;
      release(&ptable.lock);
      return 0;
    }
  }
  release(&ptable.lock);
  return -1;
}

void
procdump(void)
{
  static char *states[] = {
  [UNUSED]    "unused",
  [EMBRYO]    "embryo",
  [SLEEPING]  "sleep ",
  [RUNNABLE]  "runble",
  [RUNNING]   "run   ",
  [ZOMBIE]    "zombie"
  };
  int i;
  struct proc *p;
  char *state;
  uint pc[10];

  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
    if(p->state == UNUSED)
      continue;
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
      state = states[p->state];
    else
      state = "???";
    cprintf("%d %s %s", p->pid, state, p->name);
    if(p->state == SLEEPING){
      getcallerpcs((uint*)p->context->ebp+2, pc);
      for(i=0; i<10 && pc[i] != 0; i++)
        cprintf(" %p", pc[i]);
    }
    cprintf("\n");
  }
}

void
tput_start(void)
{
  acquire(&tickslock);
  tput_active = 1;
  tput_start_ticks = ticks;
  tput_finished_count = 0;
  release(&tickslock);
}

void
tput_end(void)
{
  uint delta;
  int done;
  int throughput;

  acquire(&tickslock);
  if(!tput_active){
    release(&tickslock);
    return;
  }
  tput_active = 0;
  delta = ticks - tput_start_ticks;
  done = tput_finished_count;
  release(&tickslock);

  if(delta == 0)
    delta = 1;

  throughput = (done * 100) / delta;

  cprintf("Throughput: %d processes in %d ticks (~%d proc/sec)\n",
          done, delta, throughput);
}

void
procdump_ext(void)
{
  static char *states[] = {
  [UNUSED]    "unused",
  [EMBRYO]    "embryo",
  [SLEEPING]  "sleep",
  [RUNNABLE]  "runnable",
  [RUNNING]   "running",
  [ZOMBIE]    "zombie"
  };

  struct proc *p;
  int c;
  int running_pid[NCPU];
  int running_qticks[NCPU];

  for(c = 0; c < NCPU; c++){
    running_pid[c] = -1;
    running_qticks[c] = 0;
  }

  acquire(&ptable.lock);

  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
    if(p->state == RUNNING &&
       p->assigned_cpu >= 0 &&
       p->assigned_cpu < ncpu){
      running_pid[p->assigned_cpu]   = p->pid;
      running_qticks[p->assigned_cpu]= p->qnticks;
    }
  }

  cprintf("=== after fork ===\n");
  for(c = 0; c < ncpu; c++){
    cprintf("cpu%d (%s-core) tick %d: pid=%d, qticks=%d\n",
            c,
            is_ecore(c) ? "E" : "P",
            ticks,
            running_pid[c],
            running_qticks[c]);
  }

  cprintf("name\tpid\tstate\tcpu\talgo\tlifetime_ticks\n");

  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
    char *st;
    char *algo;
    int lifetime;

    if(p->state == UNUSED)
      continue;

    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
      st = states[p->state];
    else
      st = "???";

    if(p->assigned_cpu >= 0 && p->assigned_cpu < ncpu){
      algo = is_ecore(p->assigned_cpu) ? "RR" : "FCFS";
    } else {
      algo = "??";
    }

    lifetime = ticks - p->create_tick;

    cprintf("%s\t%d\t%s\t%d\t%s\t%d\n",
            p->name,
            p->pid,
            st,
            p->assigned_cpu,
            algo,
            lifetime);
  }

  release(&ptable.lock);
}

int
sys_show_process_family(void)
{
  int pid;
  struct proc *p;
  struct proc *current_proc;
  struct proc *parent;
  int found = 0;
  
  if(argint(0, &pid) < 0)
    return -1;
  
  acquire(&ptable.lock);
  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++) {
    if(p->pid == pid && p->state != UNUSED) {
      current_proc = p;
      found = 1;
      break;
    }
  }
  
  if(!found) {
    release(&ptable.lock);
    cprintf("show_process_family: process with PID %d not found\n", pid);
    return -1;
  }
  
  cprintf("My id: %d, My parent id: %d\n", 
          current_proc->pid, 
          current_proc->parent ? current_proc->parent->pid : -1);
  
  cprintf("Children of process %d:\n", pid);
  int has_children = 0;
  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++) {
    if(p->parent == current_proc && p->state != UNUSED) {
      cprintf("Child pid: %d\n", p->pid);
      has_children = 1;
    }
  }
  if(!has_children) {
    cprintf("No children\n");
  }
  
  cprintf("Siblings of process %d:\n", pid);
  int has_siblings = 0;
  parent = current_proc->parent;
  if(parent) {
    for(p = ptable.proc; p < &ptable.proc[NPROC]; p++) {
      if(p->parent == parent && p != current_proc && p->state != UNUSED) {
        cprintf("Sibling pid: %d\n", p->pid);
        has_siblings = 1;
      }
    }
  }
  if(!has_siblings) {
    cprintf("No siblings\n");
  }
  
  release(&ptable.lock);
  return 0;
}

