#ifndef _PROC_H_
#define _PROC_H_

// Per-CPU state
struct cpu {
  uchar apicid;
  struct context *scheduler;
  struct taskstate ts;
  struct segdesc gdt[NSEGS];
  volatile uint started;
  int ncli;
  int intena;
  struct proc *proc;
};

struct context {
  uint edi;
  uint esi;
  uint ebx;
  uint ebp;
  uint eip;
};

enum procstate { UNUSED, EMBRYO, SLEEPING, RUNNABLE, RUNNING, ZOMBIE };

enum core_type { CORE_E, CORE_P };

#define BALANCE_INTERVAL_TICKS 5
#define ECORE_QUANTUM_TICKS 3

struct proc {
  uint sz;
  pde_t* pgdir;
  char *kstack;
  enum procstate state;
  int pid;
  struct proc *parent;
  struct trapframe *tf;
  struct context *context;
  void *chan;
  int killed;
  struct file *ofile[NOFILE];
  struct inode *cwd;
  char name[16];

  int assigned_cpu;
  enum core_type queue_type;
  uint create_tick;
  int qnticks;
};

#endif
